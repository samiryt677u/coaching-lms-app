# Coaching LMS — Flutter App Setup

## ⚠️ Important: what's in this folder and what's missing

This folder has `lib/` (all the actual app code) and `pubspec.yaml` (dependencies) — the
Flutter-specific platform folders (`android/`, `ios/`, etc.) are **not included**, because
generating them requires running `flutter create`, which needs the real Flutter SDK. I wrote
and reviewed every file carefully (checked all imports resolve, all braces balance, every API
call matches a tested backend endpoint), but **I could not actually run `flutter analyze` or
compile this app** — the sandbox I work in can't reach Flutter's download servers. This is
different from the PHP backend and admin panel, where I ran everything for real.

So: treat this as carefully-written but **not yet compiler-checked** code. The first `flutter pub get`
you run on it is effectively its first real test. If anything doesn't compile, paste me the exact
error and I'll fix it — that's the normal next round, same as the 3 real bugs we caught testing the
backend.

## Setup steps (do this in GitHub Codespaces, same as your APK workflow)

1. **Create a fresh Flutter project to get the platform folders:**
   ```
   flutter create coaching_lms
   ```

2. **Copy this delivery's files into it, overwriting the defaults:**
   - Copy `lib/` (this whole folder, replacing the default `lib/`)
   - Copy `pubspec.yaml` (replacing the default one)
   - Leave `android/`, `ios/`, `web/` etc. as `flutter create` generated them

3. **Set your real API URL** — edit `lib/core/constants.dart`:
   ```dart
   static const String baseUrl = 'https://yourdomain.com/lms/api';
   ```
   (There are commented examples in that file for local emulator/device testing too.)

4. **Install dependencies:**
   ```
   flutter pub get
   ```

5. **Check the Android manifest has internet permission** — open
   `android/app/src/main/AndroidManifest.xml` and confirm this line exists inside `<manifest>`:
   ```xml
   <uses-permission android:name="android.permission.INTERNET"/>
   ```
   Recent `flutter create` templates include this by default, but double-check — without it,
   every API call will silently fail on a real device even though it might work on some emulators.

6. **Run it:**
   ```
   flutter run
   ```
   or build the APK the way you already do:
   ```
   flutter build apk --release
   ```

## If `flutter pub get` or `flutter run` shows errors

Send me the exact error text. Likely categories, roughly in order of likelihood:
- A package version conflict in `pubspec.yaml` (easy fix, just adjust the version number)
- A Flutter SDK API that changed between versions (e.g. I used `WillPopScope`, which is older
  and broadly compatible, but if your Flutter version is very new it might warn — that's fine,
  warnings don't block a build)
- A typo I missed despite the manual review

None of these should be structural — the architecture (models, API service, screens, navigation)
was designed against the actual tested backend responses, so the app logic itself should be sound
even if there's a compile hiccup to iron out.

## What's built

**Student:** Home (upcoming live class, quick access, attendance %), Live/Recorded/Material
classes, Tests (list → take test with timer → auto-graded result + leaderboard), Leave apply +
history, Profile.

**Teacher:** Home (today's classes, quick actions), schedule live classes (Google Meet link),
upload recorded classes, upload study material (real file picker), mark attendance, create tests
(dynamic question builder) + publish/close + view leaderboard, approve/reject student leaves,
Profile.

**Admin:** Not built into this app — use the web admin panel (`admin_panel/`) for admin tasks, as
discussed. The signup screen still offers a Teacher/Student choice only, matching that decision.

## Not included yet (flag if you want these next)

- Fee payment screen (Razorpay checkout needs the `razorpay_flutter` package + native Android/iOS
  setup that I can't verify without a real build — better to add this as its own tested round)
- Push notifications for class reminders
- Offline caching of study material/recordings
